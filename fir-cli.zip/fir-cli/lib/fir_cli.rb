# encoding: utf-8
# This file exists for backward compatbility with require 'fir_cli'
require_relative './fir'
