# encoding: utf-8

module FIR
  VERSION = '1.6.12'
end
